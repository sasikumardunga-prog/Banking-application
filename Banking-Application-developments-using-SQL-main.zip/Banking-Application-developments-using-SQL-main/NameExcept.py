class InvalidNameError(Exception):pass
class SpaceError(BaseException):pass
class ZeroNameLengthError(Exception):pass
